library(testthat)
library(FinalProject)

test_check("FinalProject")
